@extends('system.register_page')
