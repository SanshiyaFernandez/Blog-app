<nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
    

    {{-- ADMIN TOP NAVIGATION --}}
    @include('layouts.includes.admin_top_nav')


    {{-- ADMIN SIDE NAVIGATION --}}
    @include('layouts.includes.admin_side_nav')



    <!-- /.navbar-static-side -->
</nav>