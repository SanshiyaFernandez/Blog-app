<footer class="border-top">
    <div class="container px-4 px-lg-5">
        laraval assignment
</div>
</footer>