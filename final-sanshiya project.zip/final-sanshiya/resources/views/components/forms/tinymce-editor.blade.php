<form method="post">

<textarea 
id="myeditorinstance" 
name="content"
placeholder="Type your blog content...">
</textarea>

</form>