<script src="<?php echo e(asset('js/tinymce/tinymce.min.js')); ?>" referrerpolicy="origin"></script>

<script>
  tinymce.init({
    
    selector: 'textarea#myeditorinstance', // Replace this CSS selector to match the placeholder element for TinyMCE
    plugins: 'code table lists ',

    
    
    toolbar: 'undo redo | blocks | bold italic | alignleft aligncenter alignright | indent outdent | bullist numlist | code | table'
	

  });
  
</script>


<?php /**PATH C:\xampp\htdocs\final-sanshiya\resources\views/components/head/tinymce-config.blade.php ENDPATH**/ ?>