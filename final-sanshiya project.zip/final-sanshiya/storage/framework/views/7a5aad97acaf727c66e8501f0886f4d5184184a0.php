<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.titles.users_title','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('titles.users_title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php $__env->startSection('content'); ?>



<div class="dashboard-div-form container">

<?php if(session()->has('success-user-deleted')): ?>
<div class="alert alert-success">
<?php echo e(session()->get('success-user-deleted')); ?>

</div>
<?php endif; ?>

<form method="post" action="<?php echo e(url('multipleusersdelete')); ?>">
    <?php echo e(csrf_field()); ?>

    <br>
   
    <table class="table-bordered table-striped" width="50%">
        <thead>
            
            <tr>
                <th class="text-center" width="80px"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('id'));?></th>
                <th class="text-center"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('name'));?></th>
                <th class="text-center"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('email'));?></th>

                <?php if(auth()->user()->admin == 'true' || auth()->user()->admin == 'TRUE'): ?>
                <th class="text-center"> <input type="checkbox" id="checkAll"></th>                    
                <?php endif; ?>

            </tr>
        </thead>
        <tbody>
            <?php
            $i=1;
            foreach ($users as $key => $value) {
                $id = $users[$key]->id;
                $name = $users[$key]->name;
                $email = $users[$key]->email;
                ?>
                <tr>
                    <td class="text-center"><?php echo e($id); ?></td>
                    <td class="text-center"><a href="<?php echo e(route('custom.show', $user)); ?>"><?php echo e($name); ?></a></td>
                    <td class="text-center"><?php echo e($email); ?></td>
                    
                    <?php if(auth()->user()->admin == 'true' || auth()->user()->admin == 'TRUE'): ?>
                    <td class="text-center"><input name='id[]' type="checkbox" id="checkItem" 
                    value="<?php echo $users[$key]->id; ?>">                        
                    <?php endif; ?>


                    </tr>
                    <?php $i++; }?>
                </tbody>
            </table>
            <br>
            <?php if(auth()->user()->admin == 'true' || auth()->user()->admin == 'TRUE'): ?>
            <input 
            class="btn btn-primary button-hover" 
            type="submit" 
            name="submit" 
            value="Delete"/>              
            <?php endif; ?>
        </form>

        
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    </script>
    <script language="javascript">
        $("#checkAll").click(function () {
            $('input:checkbox').not(this).prop('checked', this.checked);
        });
    </script>



</div>


    
<?php $__env->stopSection(); ?>


















<?php echo $__env->make('pages.profile_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog-management-laravel-master\resources\views/dashboard/users/users.blade.php ENDPATH**/ ?>