<?php $__env->startSection('content'); ?>

<style>
 
 @media only screen and (max-width: 1200px) {  
    .potd {
    width: 250px;
    height: auto;
  }
}



</style>

<div class="dashboard-div">
    <h3>Welcome back <?php echo e(auth()->user()->name); ?>!</h3>
 </div>

 <div class="dashboard-div-second">
 <h5>Photo of the day:</h4>

 <img 
 class="potd"
 style="border-radius: 10px"
 width="450"
 height="300"
 src="https://source.unsplash.com/random" 
 alt="">
 
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.profile_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\final-sanshiya\resources\views/layouts/includes/profile_page_content_section.blade.php ENDPATH**/ ?>