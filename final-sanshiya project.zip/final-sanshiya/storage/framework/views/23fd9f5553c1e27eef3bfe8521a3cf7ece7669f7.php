<footer class="border-top">
    <div class="container px-4 px-lg-5">
        laraval assignment
</div>
</footer><?php /**PATH C:\xampp\htdocs\final-sanshiya\resources\views/components/footer.blade.php ENDPATH**/ ?>