<nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
    

    
    <?php echo $__env->make('layouts.includes.admin_top_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    
    <?php echo $__env->make('layouts.includes.admin_side_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <!-- /.navbar-static-side -->
</nav><?php /**PATH C:\xampp\htdocs\blog-management-laravel-master\resources\views/layouts/includes/admin_nav.blade.php ENDPATH**/ ?>