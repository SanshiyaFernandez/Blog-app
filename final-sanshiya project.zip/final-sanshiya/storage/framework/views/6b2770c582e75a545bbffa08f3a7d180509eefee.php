<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.titles.posts_title','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('titles.posts_title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>

<?php if(session()->has('success-edit')): ?>
<div 
style="margin-top: 30px;"
class="alert alert-success">
<?php echo e(session()->get('success-edit')); ?>

</div>
<?php endif; ?>


<?php if(session()->has('delete-post')): ?>
<div 
style="margin-top: 30px;"
class="alert alert-danger">
<?php echo e(session()->get('delete-post')); ?>

</div>
<?php endif; ?>


<?php if(auth()->user()->admin == 'true' || auth()->user()->admin == 'TRUE'): ?>


<div class="container">


<?php if(count($posts) > 0): ?>

<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <div class="col-xs-12 col-md-3">
                  <div class="color-block-wrapper">
                      <div class="color-block color-block-lblue">
    
                              <?php echo e($post->title); ?>

                     
                          <div class="color-block-text">
                               <?php echo e($post->short_description); ?>

                          </div>
            
                          <img 
            style="border-radius: 10px;margin-top: 5px"
            height="140"
            width="100"
            
            <?php if($post->picture == '/storage/images/no-picture'): ?>

            src="<?php echo e($post->random); ?>" 
                

            <?php else: ?> 

            src="<?php echo e($post->picture); ?>" 

            <?php endif; ?>

            alt="Not Available"
            title="Not Available">
        
                      </div>
                      
              <div class="color-block-bottom">

              <a href="<?php echo e(route('post-index',$post->slug)); ?>" class="btn btn-transparent-lblue">Show this post
              </a>

              <a 
              style="margin-top: 10px" 
              href="<?php echo e(route('posts.edit', $post->slug)); ?>" 
              class="btn btn-primary2">Edit this post
            </a>

              </div>
    

                  </div>
              </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php else: ?> 

<div class="dashboard-div">
    <h3>There are no posts right now at the moment.</h3>
</div>
    
<?php endif; ?>

<?php else: ?> 


<?php if(count($auth_user->posts) > 0): ?>

<?php $__currentLoopData = $auth_user->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<div class="col-xs-12 col-md-3">
    <div class="color-block-wrapper">
        <div class="color-block color-block-lblue">

                <?php echo e($post->title); ?>

       
            <div class="color-block-text">
                 <?php echo e($post->short_description); ?>

            </div>

            <img 
            style="border-radius: 10px;margin-top: 5px"
            height="140"
            width="100"
            
            <?php if($post->picture == '/storage/images/no-picture'): ?>

            src="<?php echo e($post->random); ?>" 
                

            <?php else: ?> 

            src="<?php echo e($post->picture); ?>" 

            <?php endif; ?>

            alt="Not Available"
            title="Not Available">
          
        </div>
        
<div class="color-block-bottom">

<a href="<?php echo e(route('post-index',$post->slug)); ?>" class="btn btn-transparent-lblue">Show this post
</a>

<a 
style="margin-top: 10px" 
href="<?php echo e(route('posts.edit', $post->slug)); ?>" 
class="btn btn-primary2">Edit this post
</a>

</div>


    </div>
</div>
   

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php else: ?>

<div class="dashboard-div">
    <h3>You don't have any posts at the moment...</h3>
</div>

<?php endif; ?>

</div> 


<?php endif; ?>



<?php $__env->stopSection(); ?>




<?php $__env->startSection('pagination'); ?>

<div class="row">
    <center><?php echo e($posts->links('pagination::bootstrap-4')); ?></center>
</div> 
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('pages.profile_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\final-sanshiya\resources\views/dashboard/posts/posts.blade.php ENDPATH**/ ?>