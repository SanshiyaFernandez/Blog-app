<ul class="navbar-nav ms-auto py-4 py-lg-0">

    <li class="nav-item">
        <a 
        class="nav-link px-lg-3 py-3 py-lg-4" 
        href="<?php echo e(route('homepage')); ?>">Home</a>
    </li>

    <li class="nav-item">
        <a 
        class="nav-link px-lg-3 py-3 py-lg-4" 
        href="<?php echo e(route('about-me')); ?>">About</a>
    </li>

    <li class="nav-item">
        <a 
        class="nav-link px-lg-3 py-3 py-lg-4" 
        href="<?php echo e(route('contact-me')); ?>">Contact</a>
    </li>

    <?php if(!auth()->user()): ?>

    <li class="nav-item">
        <a 
        class="nav-link px-lg-3 py-3 py-lg-4" 
        href="/login">Log In</a>
    </li>

    <li class="nav-item">
        <a 
        class="nav-link px-lg-3 py-3 py-lg-4" 
        href="/register">Register</a>
    </li>
        
    <?php else: ?>
        
    <li class="nav-item">
        <a 
        class="nav-link px-lg-3 py-3 py-lg-4" 
        href="<?php echo e(route('profile-index')); ?>">Profile</a>
    </li>

    <li class="nav-item">
        <a 
        class="nav-link px-lg-3 py-3 py-lg-4" 
        href="/logout">Logout</a>
    </li>

    <?php endif; ?>

    
  <?php if(Auth::check()): ?>



  <li class="nav-item">
      <a 
      class="nav-link px-lg-3 py-3 py-lg-4" 
      href="<?php echo e(route('createblog')); ?>">Create Blog</a>
  </li>


    
  <?php endif; ?>
        


</ul><?php /**PATH C:\xampp\htdocs\blog-management-laravel-master\resources\views/components/navbar_menu.blade.php ENDPATH**/ ?>